clc;
clear all;
close all;
warning('off');

imgPath = '../Data/';
savePath = '../Results/';
if (exist(savePath, 'dir') == 0), mkdir(savePath); end
load('41matlab3.mat')
dir_src = dir(fullfile('../Data/','*.tif'));

for i=1:length(dir_src)
    filename = dir_src(i).name;

savename = filename(1:end-4);

info = imfinfo([imgPath filename]);

imageHeight = info.Height;
imageWidth = info.Width;
imageFrames = length(info);

stack = zeros(imageHeight,imageWidth,imageFrames);

for ii = 1:imageFrames
    currentImage = imread([imgPath filename],'tif', ii);
    stack(:,:,ii) = currentImage;
end

composition_image1 = zeros(imageHeight,imageWidth);
composition_image2 = zeros(imageHeight,imageWidth);
status_indicator   = zeros(imageHeight,imageWidth) - 10;

options = optimoptions('fmincon', 'Display', 'none');

parfor ii = 1:imageHeight
    for jj = 1:imageWidth
        if stack(ii,jj,1) < 10
	    % ignore background pixels for faster computation
            composition_image1(ii,jj) = 0;
            composition_image2(ii,jj) = 0;

        else
            [predicted_vals, ~, exitflag, ~] = fmincon(@(coeffs) signalseparation6G_fmincon(mCardinal, mfRFP_A,squeeze(stack(ii,jj,:)), coeffs), ... % obj. fun.
                                        [0 0], ... % initial guess
                                        [], [], ... % inequalities (N/A)
                                        [1,1], ... % equality constraint left hand side
                                        1, ... % equality constraint right hand side -- this ensures they add up to 1
                                        [0,0], ... % lower bounds
                                        [1,1], ... % upper bounds
                                        [], ... % nonlinear options (N/A)
                                        options); % see options variable above --  currently only disables print output
              composition_image1(ii,jj) = predicted_vals(1);
              composition_image2(ii,jj) = predicted_vals(2);
              status_indicator(ii, jj)  = exitflag; % we need this value to know if the optimization succeeded
        end
    end
disp(['Done with ' num2str(ii) ' of ' num2str(imageHeight)]);      
end

% Clip the values so that they are all between 0 and 1 inclusive.
% This is technically not necessary for this approach, but we do it anyway
% just to be safe.
composition_image1(composition_image1 <0) = 0;
composition_image1(composition_image1 >1) = 1;
composition_image2(composition_image2 <0) = 0;
composition_image2(composition_image2 >1) = 1;

% Multiply the values with the first frame in the stack
% to compute intensities for each channel.
% Because we strictly defined the values to add up to 1 using
% the MATLAB optimization options and specifying an equality constraint,
% these channels also add up to exactly the original video.
mCardinal_ch = composition_image1.*stack(:,:,1);
mfRFP_A_ch = composition_image2.*stack(:,:,1); 
% Save resulting new images in the working directory.
imwrite(uint16(mCardinal_ch), [[savePath savename] 'mCardinal.tif']); 
imwrite(uint16(mfRFP_A_ch), [[savePath savename] 'mfRFP_A.tif']);

end
